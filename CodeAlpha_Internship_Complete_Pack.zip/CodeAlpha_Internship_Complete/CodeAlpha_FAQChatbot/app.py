from flask import Flask, request, render_template_string
import json, re
from difflib import SequenceMatcher
app=Flask(__name__)
with open('faqs.json',encoding='utf-8') as f: FAQS=json.load(f)
def clean(s): return re.sub(r'[^a-z0-9 ]',' ',s.lower()).strip()
def score(a,b):
    a,b=clean(a),clean(b)
    if not a or not b: return 0
    words=set(a.split()); other=set(b.split())
    overlap=len(words & other)/max(1,len(words | other))
    return max(overlap,SequenceMatcher(None,a,b).ratio())
def answer(question):
    best=max(FAQS,key=lambda item:score(question,item['question']))
    if score(question,best['question'])<0.22:
        return "I'm not sure about that yet. Try asking about AI, machine learning, Python, or internship submissions."
    return best['answer']
HTML='''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>FAQ Chatbot</title><style>body{font-family:Arial;background:#f2f5fb;padding:20px;color:#222}.card{max-width:680px;margin:auto;background:white;padding:20px;border-radius:16px}input{width:100%;padding:12px;box-sizing:border-box;border:1px solid #ccd;border-radius:8px}button{padding:11px 16px;background:#285ed8;color:white;border:0;border-radius:8px;margin-top:10px}.answer{background:#edf3ff;padding:15px;border-radius:10px;margin-top:15px}</style></head><body><div class="card"><h1>FAQ Chatbot</h1><p>Ask a question about AI, Python, or internship basics.</p><form method="post"><input name="question" value="{{ question }}" placeholder="Type your question..." required><button>Ask</button></form>{% if response %}<div class="answer"><b>Bot:</b> {{ response }}</div>{% endif %}<h3>Sample questions</h3><ul>{% for faq in faqs %}<li>{{faq.question}}</li>{% endfor %}</ul></div></body></html>'''
@app.route('/',methods=['GET','POST'])
def home():
 q=''; response=''
 if request.method=='POST':
  q=request.form.get('question','').strip(); response=answer(q)
 return render_template_string(HTML,question=q,response=response,faqs=FAQS)
if __name__=='__main__': app.run(debug=False)
