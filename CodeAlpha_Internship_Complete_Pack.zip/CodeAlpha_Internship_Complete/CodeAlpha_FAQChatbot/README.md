# FAQ Chatbot
This chatbot compares a user's question to a small local FAQ list and returns the closest matching answer. It uses simple token overlap and text similarity (not a full trained NLP model).
## Run
- `python -m pip install -r requirements.txt`
- `python app.py`
- Visit `http://127.0.0.1:5000` in a browser.
## Customize
Edit `faqs.json` to add or change questions and answers. Use accurate facts for your chosen topic.
