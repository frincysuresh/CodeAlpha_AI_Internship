# Music Generation Demo
Creates an original short melody in MIDI format using a scale, repeated pattern, and randomized note choices.\n**Honesty note:** this is a music-generation prototype and does not train an RNN/GAN or learn from a dataset. It is suitable for demonstrating basic programmatic generation, but not as evidence of neural-network training.
## Run
`python -m pip install -r requirements.txt`
`python generate_music.py`
The output file `generated_melody.mid` can be opened with a MIDI player or music editor. Re-run to create another variation.
