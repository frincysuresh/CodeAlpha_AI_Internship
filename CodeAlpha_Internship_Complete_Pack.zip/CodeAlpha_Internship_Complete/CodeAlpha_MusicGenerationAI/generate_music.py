"""Rule-based demo: generates a short melody MIDI file. Not a trained AI model."""
import random
from mido import MidiFile, MidiTrack, Message, MetaMessage


def create_melody(output='generated_melody.mid', bars=8, bpm=110):
    mid=MidiFile(ticks_per_beat=480)
    track=MidiTrack(); mid.tracks.append(track)
    track.append(MetaMessage('set_tempo',tempo=int(60_000_000/bpm),time=0))
    # C major scale, melody is selected from a small consonant pool
    notes=[60,62,64,65,67,69,71,72,74,76,79]
    pattern=[0,2,4,2,5,4,2,0]
    for bar in range(bars):
        for step in range(4):
            note=random.choice(notes) if random.random()<0.45 else notes[pattern[(step+bar)%len(pattern)]]
            length=480 # quarter note
            track.append(Message('note_on',note=note,velocity=80,time=0))
            track.append(Message('note_off',note=note,velocity=0,time=length))
    track.append(MetaMessage('end_of_track'))
    mid.save(output)
    print(f'Saved {output}. Open it in a MIDI player/editor to listen.')
if __name__=='__main__': create_melody()
