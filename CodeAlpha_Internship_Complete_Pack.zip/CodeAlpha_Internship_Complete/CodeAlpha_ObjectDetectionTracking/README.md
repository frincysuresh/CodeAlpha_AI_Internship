# Object Detection and Tracking
Uses a pretrained YOLO model to detect objects and track them across video frames, showing labels and IDs.
## Run
- Install Python 3.10+: `python -m pip install -r requirements.txt`
- Webcam: `python track_objects.py`
- Video file: `python track_objects.py --source path/to/video.mp4`
- Optional model selection: `python track_objects.py --model yolo11n.pt`
First run downloads model weights and requires internet. Webcam use may require OS camera permission. Use only videos/camera feeds you have permission to use; avoid identifying or tracking people for sensitive purposes.
