"""YOLO webcam/video object detection with tracking IDs using Ultralytics."""
from ultralytics import YOLO
import argparse

def main():
    parser=argparse.ArgumentParser(description='Detect and track objects in webcam/video.')
    parser.add_argument('--source',default='0',help='Webcam index (0) or video path')
    parser.add_argument('--model',default='yolo11n.pt',help='YOLO model filename; downloads on first run')
    args=parser.parse_args()
    source=0 if args.source=='0' else args.source
    model=YOLO(args.model)
    # persist tracking across frames; show annotated video until the display window closes
    model.track(source=source,show=True,tracker='bytetrack.yaml',persist=True)
if __name__=='__main__': main()
