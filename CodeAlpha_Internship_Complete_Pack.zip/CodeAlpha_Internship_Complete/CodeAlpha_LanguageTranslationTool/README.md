# Language Translation Tool
A simple Flask web app that lets a user enter text, choose source/target language, translate, and copy the result.

## Run
1. Install Python 3.10+.
2. In this folder run: `python -m pip install -r requirements.txt`
3. Run: `python app.py`
4. Open the local address printed by Flask (usually `http://127.0.0.1:5000`).
Translation needs internet and the third-party service. Languages included in the dropdown are a starter selection.
