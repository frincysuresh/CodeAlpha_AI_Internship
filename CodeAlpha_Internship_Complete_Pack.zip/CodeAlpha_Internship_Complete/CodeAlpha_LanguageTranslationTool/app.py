from flask import Flask, request, render_template_string
from deep_translator import GoogleTranslator


app = Flask(__name__)
LANGUAGES = {
    "auto": "Auto detect", "en": "English", "hi": "Hindi", "kn": "Kannada",
    "ta": "Tamil", "te": "Telugu", "ml": "Malayalam", "fr": "French",
    "es": "Spanish", "de": "German", "it": "Italian", "ja": "Japanese",
    "ko": "Korean", "ar": "Arabic", "pt": "Portuguese", "ru": "Russian"
}
PAGE = '''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Language Translator</title>
<style>body{font-family:Arial;background:#f4f6fb;margin:0;padding:24px;color:#18243b}.box{max-width:760px;margin:auto;background:white;padding:22px;border-radius:16px;box-shadow:0 4px 20px #0001}textarea{width:100%;min-height:140px;padding:12px;box-sizing:border-box;border:1px solid #ccd3df;border-radius:10px;font-size:16px}select,button{padding:10px;border-radius:8px;border:1px solid #ccd3df;margin:5px}button{background:#2b62d9;color:white;border:0;cursor:pointer}.result{white-space:pre-wrap;background:#f2f5fa;padding:14px;border-radius:10px}</style></head><body><div class="box"><h1>Language Translation Tool</h1><form method="post"><label>Text to translate</label><textarea name="text" required>{{ text }}</textarea><p><label>From </label><select name="source">{% for k,v in languages.items() %}<option value="{{k}}" {% if k==source %}selected{% endif %}>{{v}}</option>{% endfor %}</select>
<label>To </label><select name="target">{% for k,v in languages.items() if k!='auto' %}<option value="{{k}}" {% if k==target %}selected{% endif %}>{{v}}</option>{% endfor %}</select><button type="submit">Translate</button></p></form>
{% if translated %}<h3>Translation</h3><div class="result" id="result">{{ translated }}</div><button onclick="navigator.clipboard.writeText(document.getElementById('result').innerText)">Copy result</button>{% endif %}{% if error %}<p style="color:#b00">{{ error }}</p>{% endif %}</div></body></html>'''
@app.route('/', methods=['GET','POST'])
def index():
    text=''; source='auto'; target='en'; translated=''; error=''
    if request.method=='POST':
        text=request.form.get('text','').strip(); source=request.form.get('source','auto'); target=request.form.get('target','en')
        try:
            translator=GoogleTranslator(source='auto' if source=='auto' else source, target=target)
            translated=translator.translate(text) if text else ''
        except Exception as exc:
            error=f"Translation failed. Check your internet connection and try again. ({type(exc).__name__})"
    return render_template_string(PAGE,text=text,source=source,target=target,languages=LANGUAGES,translated=translated,error=error)
if __name__=='__main__':
    app.run(debug=False)
